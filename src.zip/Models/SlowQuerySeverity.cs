namespace SqlMonitor.Models
{
    // This enum is now defined in SlowQueryHistory.cs
    // Keeping this file for reference, but the enum is commented out to avoid duplicate definition
    /*
    public enum SlowQuerySeverity
    {
        Info,
        Warning,
        Critical
    }
    */
} 