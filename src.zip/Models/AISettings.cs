namespace SqlMonitor.Models
{
    public class AISettings
    {
        public string? Endpoint { get; set; }
        public string? ApiKey { get; set; }
        public string? Deployment { get; set; }
        public string? ApiVersion { get; set; }
        
        // Add missing properties referenced in AIQueryAnalysisService
        public string? Provider { get; set; }
        public string? DeploymentName { get; set; }
        public string? ModelName { get; set; }
        public int MaxTokens { get; set; } = 2000;
        public double Temperature { get; set; } = 0.7;
    }
} 