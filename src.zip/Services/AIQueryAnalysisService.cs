using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SqlMonitor.Interfaces;
using SqlMonitor.Models;

namespace SqlMonitor.Services
{
    public class AIQueryAnalysisService : IAIQueryAnalysisService
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger<AIQueryAnalysisService> _logger;
        private readonly AISettings _settings;

        public AIQueryAnalysisService(
            HttpClient httpClient,
            ILogger<AIQueryAnalysisService> logger,
            IOptions<AISettings> settings)
        {
            _httpClient = httpClient;
            _logger = logger;
            _settings = settings.Value;
        }

        public async Task<string> AnalyzeQueryAsync(string query, string databaseContext)
        {
            try
            {
                _logger.LogInformation("Analyzing query with AI: {Query}", query);

                // Use the Provider property from AISettings
                string provider = _settings.Provider ?? "openai";

                // Use integer values directly instead of converting from string
                int maxTokens = _settings.MaxTokens;
                double temperature = _settings.Temperature;

                string prompt = $"Analyze this SQL query for a {provider} database and suggest optimizations:\n\n{query}\n\nDatabase context: {databaseContext}";

                var response = await SendOpenAIRequestAsync(prompt);
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error analyzing query with AI");
                return $"Error analyzing query: {ex.Message}";
            }
        }

        private async Task<string> SendOpenAIRequestAsync(string prompt)
        {
            try
            {
                var requestUrl = $"{_settings.Endpoint}/openai/deployments/{_settings.Deployment}/completions?api-version={_settings.ApiVersion}";

                var requestData = new
                {
                    prompt = prompt,
                    max_tokens = _settings.MaxTokens,
                    temperature = _settings.Temperature,
                    top_p = 1,
                    frequency_penalty = 0,
                    presence_penalty = 0,
                    stop = (string[])null
                };

                var requestContent = new StringContent(
                    JsonSerializer.Serialize(requestData),
                    Encoding.UTF8,
                    "application/json");

                _httpClient.DefaultRequestHeaders.Clear();
                _httpClient.DefaultRequestHeaders.Add("api-key", _settings.ApiKey);

                var response = await _httpClient.PostAsync(requestUrl, requestContent);
                response.EnsureSuccessStatusCode();

                var responseContent = await response.Content.ReadAsStringAsync();
                var responseObject = JsonSerializer.Deserialize<JsonElement>(responseContent);

                if (responseObject.TryGetProperty("choices", out var choices) &&
                    choices.GetArrayLength() > 0 &&
                    choices[0].TryGetProperty("text", out var text))
                {
                    return text.GetString()?.Trim() ?? "No response from AI service";
                }

                return "Invalid response format from AI service";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error sending request to OpenAI");
                return $"Error: {ex.Message}";
            }
        }

        public async Task<QueryOptimizationResult> OptimizeQueryAsync(string query, string databaseContext)
        {
            try
            {
                _logger.LogInformation("Optimizing query with AI: {Query}", query);

                // Use the ModelName property from AISettings
                string model = _settings.ModelName ?? "gpt-4";

                var messages = new List<object>
                {
                    new { role = "system", content = "You are an expert SQL query optimizer. Analyze the provided SQL query and suggest optimizations." },
                    new { role = "user", content = $"Optimize this SQL query for a SQL Server database:\n\n{query}\n\nDatabase context: {databaseContext}" }
                };

                var requestData = new
                {
                    model = model,
                    messages = messages,
                    max_tokens = _settings.MaxTokens,
                    temperature = _settings.Temperature,
                    top_p = 1,
                    frequency_penalty = 0,
                    presence_penalty = 0
                };

                var requestContent = new StringContent(
                    JsonSerializer.Serialize(requestData),
                    Encoding.UTF8,
                    "application/json");

                _httpClient.DefaultRequestHeaders.Clear();
                _httpClient.DefaultRequestHeaders.Add("api-key", _settings.ApiKey);

                var requestUrl = $"{_settings.Endpoint}/v1/chat/completions";
                var response = await _httpClient.PostAsync(requestUrl, requestContent);
                response.EnsureSuccessStatusCode();

                var responseContent = await response.Content.ReadAsStringAsync();
                return ParseOptimizationResponse(responseContent, query);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error optimizing query with AI");
                return new QueryOptimizationResult
                {
                    OptimizedQuery = query,
                    Explanation = $"Error optimizing query: {ex.Message}",
                    IndexRecommendations = new List<string>(),
                    IsSimulated = false
                };
            }
        }

        private QueryOptimizationResult ParseOptimizationResponse(string responseContent, string originalQuery)
        {
            try
            {
                var responseObject = JsonSerializer.Deserialize<JsonElement>(responseContent);

                string? optimizedQuery = null;
                string? explanation = null;
                var indexRecommendations = new List<string>();

                if (responseObject.TryGetProperty("choices", out var choices) &&
                    choices.GetArrayLength() > 0 &&
                    choices[0].TryGetProperty("message", out var message) &&
                    message.TryGetProperty("content", out var content))
                {
                    var responseText = content.GetString();
                    if (responseText != null)
                    {
                        // Extract optimized query
                        optimizedQuery = ExtractOptimizedQuery(responseText) ?? originalQuery;
                        
                        // Extract explanation
                        explanation = ExtractExplanation(responseText) ?? "No explanation provided";
                        
                        // Extract index recommendations
                        indexRecommendations = ExtractIndexRecommendations(responseText);
                    }
                }

                return new QueryOptimizationResult
                {
                    OptimizedQuery = optimizedQuery ?? originalQuery,
                    Explanation = explanation ?? "Failed to parse AI response",
                    IndexRecommendations = indexRecommendations,
                    IsSimulated = false
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error parsing optimization response");
                return new QueryOptimizationResult
                {
                    OptimizedQuery = originalQuery,
                    Explanation = $"Error parsing response: {ex.Message}",
                    IndexRecommendations = new List<string>(),
                    IsSimulated = false
                };
            }
        }

        private string? ExtractOptimizedQuery(string responseText)
        {
            // Simple extraction logic - look for SQL between ```sql and ``` markers
            var startMarker = "```sql";
            var endMarker = "```";
            
            var startIndex = responseText.IndexOf(startMarker, StringComparison.OrdinalIgnoreCase);
            if (startIndex >= 0)
            {
                startIndex += startMarker.Length;
                var endIndex = responseText.IndexOf(endMarker, startIndex, StringComparison.OrdinalIgnoreCase);
                if (endIndex >= 0)
                {
                    return responseText.Substring(startIndex, endIndex - startIndex).Trim();
                }
            }
            
            // Fallback: try without the sql marker
            startIndex = responseText.IndexOf("```");
            if (startIndex >= 0)
            {
                startIndex += 3;
                var endIndex = responseText.IndexOf("```", startIndex, StringComparison.OrdinalIgnoreCase);
                if (endIndex >= 0)
                {
                    return responseText.Substring(startIndex, endIndex - startIndex).Trim();
                }
            }
            
            return null;
        }

        private string? ExtractExplanation(string responseText)
        {
            // Look for explanation after the code block
            var marker = "```";
            var lastCodeBlockIndex = responseText.LastIndexOf(marker);
            
            if (lastCodeBlockIndex >= 0)
            {
                var explanationStart = lastCodeBlockIndex + marker.Length;
                if (explanationStart < responseText.Length)
                {
                    return responseText.Substring(explanationStart).Trim();
                }
            }
            
            // If no code block found, return the whole response
            return responseText;
        }

        private List<string> ExtractIndexRecommendations(string responseText)
        {
            var recommendations = new List<string>();
            
            // Look for index recommendations in the text
            // This is a simple implementation - could be enhanced with regex
            var indexMarkers = new[] { "CREATE INDEX", "CREATE NONCLUSTERED INDEX", "INDEX RECOMMENDATION" };
            
            var lines = responseText.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var line in lines)
            {
                foreach (var marker in indexMarkers)
                {
                    if (line.Contains(marker, StringComparison.OrdinalIgnoreCase))
                    {
                        recommendations.Add(line.Trim());
                        break;
                    }
                }
            }
            
            return recommendations;
        }
    }
} 