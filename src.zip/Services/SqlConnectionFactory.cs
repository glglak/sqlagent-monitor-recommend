using System.Data;
using Microsoft.Data.SqlClient;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using SqlMonitor.Interfaces;
using SqlMonitor.Models;
using System;
using System.Data.Common;

namespace SqlMonitor.Services
{
    public class SqlConnectionFactory : ISqlConnectionFactory
    {
        private readonly SqlServerSettings _settings;

        public SqlConnectionFactory(IOptions<SqlServerSettings> settings)
        {
            _settings = settings.Value;
        }

        public async Task<DbConnection> GetConnectionAsync(string databaseName)
        {
            var connectionString = GetConnectionString(databaseName);
            var connection = new SqlConnection(connectionString);
            await connection.OpenAsync();
            return connection;
        }

        public string GetConnectionString(string databaseName)
        {
            var builder = new SqlConnectionStringBuilder(_settings.ConnectionString);
            
            // Only set the database name if it's not "master" (which is already in the connection string)
            if (!string.IsNullOrEmpty(databaseName) && !databaseName.Equals("master", StringComparison.OrdinalIgnoreCase))
            {
                builder.InitialCatalog = databaseName;
            }
            
            return builder.ConnectionString;
        }

        public async Task<DbConnection> CreateConnectionAsync(string? connectionString = null)
        {
            // Use the provided connection string or the default one
            var connString = connectionString ?? _settings.ConnectionString;
            
            var connection = new SqlConnection(connString);
            await connection.OpenAsync();
            return connection;
        }
    }
} 