using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using SqlMonitor.Models;

namespace SqlMonitor.Interfaces
{
    public interface IIndexMonitorService
    {
        Task<IEnumerable<IndexInfo>> GetFragmentedIndexesAsync(CancellationToken cancellationToken);
        Task ReindexAsync(IndexInfo indexInfo, CancellationToken cancellationToken);
        
        /// <summary>
        /// Gets missing indexes for a database
        /// </summary>
        Task<List<MissingIndex>> GetMissingIndexesAsync(string databaseName);
        
        /// <summary>
        /// Simulates index creation on a database
        /// </summary>
        Task<IndexCreationResult> SimulateIndexCreationAsync(string databaseName, string table, string columns, string? includeColumns = null);
    }
} 