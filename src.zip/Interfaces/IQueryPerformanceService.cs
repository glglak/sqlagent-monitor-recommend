using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using SqlMonitor.Models;

namespace SqlMonitor.Interfaces
{
    public interface IQueryPerformanceService
    {
        /// <summary>
        /// Gets a list of all databases
        /// </summary>
        Task<List<DatabaseInfo>> GetDatabasesAsync();
        
        /// <summary>
        /// Gets the status of a database
        /// </summary>
        Task<string> GetDatabaseStatusAsync(string databaseId);
        
        /// <summary>
        /// Gets the database name from its ID
        /// </summary>
        Task<string> GetDatabaseNameAsync(string databaseId);
        
        /// <summary>
        /// Gets performance metrics for a database
        /// </summary>
        Task<PerformanceMetrics> GetPerformanceMetricsAsync(string databaseName);
        
        /// <summary>
        /// Gets slow queries for a database
        /// </summary>
        Task<List<SlowQuery>> GetSlowQueriesAsync(string databaseName);
        
        /// <summary>
        /// Simulates a slow query on a database
        /// </summary>
        Task<SlowQuerySimulationResult> SimulateSlowQueryAsync(string databaseName);
        
        /// <summary>
        /// Applies a fix to a slow query
        /// </summary>
        Task<QueryFixResult> ApplyQueryFixAsync(string databaseName, string queryId, string fixType, string query);

        Task<IEnumerable<SlowQuery>> GetSlowQueriesFromQueryStoreAsync(CancellationToken cancellationToken);

        Task<IEnumerable<SlowQuery>> GetSlowQueriesAsync(string databaseName, CancellationToken cancellationToken);

        Task<IEnumerable<SlowQueryHistory>> GetHistoricalSlowQueriesAsync(string databaseName);
    }
} 