using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SqlMonitor.Interfaces;
using SqlMonitor.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace SqlMonitor.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DatabasesController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<DatabasesController> _logger;
        private readonly ISqlConnectionFactory _connectionFactory;
        private readonly IQueryPerformanceService _queryPerformanceService;
        private readonly IIndexMonitorService _indexMonitorService;
        private readonly IAIQueryAnalysisService _aiQueryAnalysisService;

        public DatabasesController(
            IConfiguration configuration,
            ILogger<DatabasesController> logger,
            ISqlConnectionFactory connectionFactory,
            IQueryPerformanceService queryPerformanceService,
            IIndexMonitorService indexMonitorService,
            IAIQueryAnalysisService aiQueryAnalysisService)
        {
            _configuration = configuration;
            _logger = logger;
            _connectionFactory = connectionFactory;
            _queryPerformanceService = queryPerformanceService;
            _indexMonitorService = indexMonitorService;
            _aiQueryAnalysisService = aiQueryAnalysisService;
        }

        // GET: api/databases
        [HttpGet]
        public async Task<IActionResult> GetDatabases()
        {
            try
            {
                _logger.LogInformation("Getting all databases");
                
                // Use the service to get databases instead of direct SQL
                var databases = await _queryPerformanceService.GetDatabasesAsync();
                
                _logger.LogInformation($"Found {databases.Count} databases");
                return Ok(databases);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting databases");
                return StatusCode(500, new { error = ex.Message });
            }
        }

        // GET: api/databases/{databaseId}/status
        [HttpGet("{databaseId}/status")]
        public async Task<IActionResult> GetDatabaseStatus(string databaseId)
        {
            try
            {
                _logger.LogInformation($"Checking status for database ID: {databaseId}");
                
                // Use the service to check database status
                var status = await _queryPerformanceService.GetDatabaseStatusAsync(databaseId);
                
                _logger.LogInformation($"Database ID {databaseId} status: {status}");
                return Ok(new { status });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error getting status for database {databaseId}");
                return StatusCode(500, new { error = ex.Message });
            }
        }

        // GET: api/databases/{databaseId}/performance
        [HttpGet("{databaseId}/performance")]
        public async Task<IActionResult> GetPerformanceMetrics(string databaseId)
        {
            try
            {
                _logger.LogInformation($"Getting performance metrics for database ID: {databaseId}");
                
                // Get the database name from the ID
                var dbName = await _queryPerformanceService.GetDatabaseNameAsync(databaseId);

                if (string.IsNullOrEmpty(dbName))
                {
                    _logger.LogWarning($"Database with ID {databaseId} not found");
                    return NotFound(new { error = "Database not found" });
                }

                // Get performance metrics from the service
                var metrics = await _queryPerformanceService.GetPerformanceMetricsAsync(dbName);
                
                _logger.LogInformation($"Retrieved performance metrics for database {dbName}");
                return Ok(metrics);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error getting performance metrics for database {databaseId}");
                return StatusCode(500, new { error = ex.Message });
            }
        }

        // GET: api/databases/{databaseId}/slowqueries
        [HttpGet("{databaseId}/slowqueries")]
        public async Task<IActionResult> GetSlowQueries(string databaseId)
        {
            try
            {
                _logger.LogInformation($"Getting slow queries for database ID: {databaseId}");
                
                // Get the database name from the ID
                var dbName = await _queryPerformanceService.GetDatabaseNameAsync(databaseId);

                if (string.IsNullOrEmpty(dbName))
                {
                    _logger.LogWarning($"Database with ID {databaseId} not found");
                    return NotFound(new { error = "Database not found" });
                }

                // Get slow queries from the service
                var slowQueries = await _queryPerformanceService.GetSlowQueriesAsync(dbName);
                
                _logger.LogInformation($"Retrieved slow queries for database {dbName}");
                return Ok(slowQueries);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error getting slow queries for database {databaseId}");
                return StatusCode(500, new { error = ex.Message });
            }
        }

        // GET: api/databases/{databaseId}/missingindexes
        [HttpGet("{databaseId}/missingindexes")]
        public async Task<IActionResult> GetMissingIndexes(string databaseId)
        {
            try
            {
                _logger.LogInformation($"Getting missing indexes for database ID: {databaseId}");
                
                // Get the database name from the ID
                var dbName = await _queryPerformanceService.GetDatabaseNameAsync(databaseId);

                if (string.IsNullOrEmpty(dbName))
                {
                    _logger.LogWarning($"Database with ID {databaseId} not found");
                    return NotFound(new { error = "Database not found" });
                }

                // Get missing indexes from the service
                var missingIndexes = await _indexMonitorService.GetMissingIndexesAsync(dbName);
                
                _logger.LogInformation($"Retrieved missing indexes for database {dbName}");
                return Ok(missingIndexes);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error getting missing indexes for database {databaseId}");
                return StatusCode(500, new { error = ex.Message });
            }
        }

        // POST: api/databases/{databaseId}/simulate/slowquery
        [HttpPost("{databaseId}/simulate/slowquery")]
        public async Task<IActionResult> SimulateSlowQuery(string databaseId)
        {
            try
            {
                _logger.LogInformation($"Simulating slow query for database ID: {databaseId}");
                
                // Get the database name from the ID
                var dbName = await _queryPerformanceService.GetDatabaseNameAsync(databaseId);

                if (string.IsNullOrEmpty(dbName))
                {
                    _logger.LogWarning($"Database with ID {databaseId} not found");
                    return NotFound(new { error = "Database not found" });
                }

                // Simulate a slow query
                var result = await _queryPerformanceService.SimulateSlowQueryAsync(dbName);
                
                _logger.LogInformation($"Simulated slow query for database {dbName}");
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error simulating slow query for database {databaseId}");
                return StatusCode(500, new { error = ex.Message });
            }
        }

        // POST: api/databases/{databaseId}/simulate/createindex
        [HttpPost("{databaseId}/simulate/createindex")]
        public async Task<IActionResult> SimulateCreateIndex(string databaseId, [FromBody] IndexCreationRequest request)
        {
            try
            {
                _logger.LogInformation($"Simulating index creation for database ID: {databaseId}");
                
                if (request == null || string.IsNullOrEmpty(request.Table) || string.IsNullOrEmpty(request.Columns))
                {
                    _logger.LogWarning("Invalid index creation request");
                    return BadRequest(new { error = "Table and columns are required" });
                }
                
                // Get the database name from the ID
                var dbName = await _queryPerformanceService.GetDatabaseNameAsync(databaseId);

                if (string.IsNullOrEmpty(dbName))
                {
                    _logger.LogWarning($"Database with ID {databaseId} not found");
                    return NotFound(new { error = "Database not found" });
                }

                // Simulate index creation
                var result = await _indexMonitorService.SimulateIndexCreationAsync(dbName, request.Table, request.Columns, request.IncludeColumns);
                
                _logger.LogInformation($"Simulated index creation for database {dbName}");
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error simulating index creation for database {databaseId}");
                return StatusCode(500, new { error = ex.Message });
            }
        }

        // POST: api/databases/{databaseId}/fix/query/{queryId}
        [HttpPost("{databaseId}/fix/query/{queryId}")]
        public async Task<IActionResult> ApplyQueryFix(string databaseId, string queryId, [FromBody] QueryFixRequest request)
        {
            try
            {
                _logger.LogInformation($"Applying fix for query {queryId} in database ID: {databaseId}");
                
                if (request == null || string.IsNullOrEmpty(request.FixType))
                {
                    _logger.LogWarning("Invalid query fix request");
                    return BadRequest(new { error = "Fix type is required" });
                }
                
                // Get the database name from the ID
                var dbName = await _queryPerformanceService.GetDatabaseNameAsync(databaseId);

                if (string.IsNullOrEmpty(dbName))
                {
                    _logger.LogWarning($"Database with ID {databaseId} not found");
                    return NotFound(new { error = "Database not found" });
                }

                // Apply query fix
                var result = await _queryPerformanceService.ApplyQueryFixAsync(dbName, queryId, request.FixType, request.Query);
                
                _logger.LogInformation($"Applied fix for query {queryId} in database {dbName}");
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error applying fix for query {queryId} in database {databaseId}");
                return StatusCode(500, new { error = ex.Message });
            }
        }

        // POST: api/openai/optimize-query
        [HttpPost("/api/openai/optimize-query")]
        public async Task<IActionResult> OptimizeQueryWithAI([FromBody] QueryOptimizationRequest request)
        {
            try
            {
                _logger.LogInformation($"Optimizing query with AI for database ID: {request.DatabaseId}");
                
                if (request == null || string.IsNullOrEmpty(request.Query))
                {
                    _logger.LogWarning("Invalid query optimization request");
                    return BadRequest(new { error = "Query is required" });
                }
                
                // Get the database name from the ID
                var dbName = await _queryPerformanceService.GetDatabaseNameAsync(request.DatabaseId);

                if (string.IsNullOrEmpty(dbName))
                {
                    _logger.LogWarning($"Database with ID {request.DatabaseId} not found");
                    return NotFound(new { error = "Database not found" });
                }

                // Optimize query with AI
                var result = await _aiQueryAnalysisService.OptimizeQueryAsync(dbName, request.Query);
                
                _logger.LogInformation($"Optimized query with AI for database {dbName}");
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error optimizing query with AI for database {request.DatabaseId}");
                return StatusCode(500, new { error = ex.Message });
            }
        }
    }

    public class IndexCreationRequest
    {
        public string? Table { get; set; }
        public string? Columns { get; set; }
        public string? IncludeColumns { get; set; }
    }

    public class QueryFixRequest
    {
        public string? FixType { get; set; }
        public string? Query { get; set; }
    }

    public class QueryOptimizationRequest
    {
        public string? DatabaseId { get; set; }
        public string? Query { get; set; }
    }
} 